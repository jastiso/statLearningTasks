import os
os.chdir('experiment')
import psiturk.experiment_server as exp
exp.launch()
