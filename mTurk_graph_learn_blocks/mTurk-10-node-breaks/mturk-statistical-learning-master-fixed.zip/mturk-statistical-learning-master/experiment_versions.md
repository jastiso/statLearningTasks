v5: exposure paths attempt to match edge frequency
v6: totally random exposure walks
v7: Hamiltonian walks
v8: eularian walks
v15: response to reviewers: modular, random walk vs hamiltonian

v20: Third set of experiments for chris's revisions, 250 subjects of alternating random/hamiltonian walks